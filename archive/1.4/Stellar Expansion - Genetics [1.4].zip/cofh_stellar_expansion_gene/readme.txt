CoFH - Stellar Expansion - Genetics
Author: King Lemming

This is a pretty straightforward mod - up to 5 more Trait Points.

In the future, I intend to experiment with cloning a bit, and perhaps add some
new traits as well.

I'm also looking at an event-driven way to "un-trait" a pop.

################################################################################
# Technologies
################################################################################

Society
--------------------------------------------------------------------------------
Gene Drive Architecture:
	Biology
	Repeatable (5x)

	Prerequisites:
		Tech - Targeted Gene Expressions

	Effects:
		+1 Trait Point
