CoFH - Stellar Expansion - Embassies
Author: King Lemming

################################################################################
# Technologies
################################################################################

Society
--------------------------------------------------------------------------------
Diplomatic Missions:
	Statecraft

	Effects:
		Unlocks - Diplomatic Action: Establish Embassy
		+1 Max Embassies

Diplomatic Coordination:
	Statecraft

	Effects:
		+1 Max Embassies

Diplomatic Corps:
	Statecraft

	Effects:
		+1 Max Embassies
