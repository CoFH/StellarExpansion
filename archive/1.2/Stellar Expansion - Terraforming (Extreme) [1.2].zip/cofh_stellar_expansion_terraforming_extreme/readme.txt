CoFH - Stellar Expansion - Terraforming (Extreme)
Author: King Lemming

################################################################################
# Technologies
################################################################################

Society
--------------------------------------------------------------------------------
Extreme World Terraformation:
	New Worlds, Rare

	Prerequisites:
		Tech - Atmospheric Manipulation

	Effects:
		Unlocks - Mechanic: Extreme World Terraformation
			Allows Molten and Frozen worlds to be terraformed:
				Molten -> Arid: 3 Liquid, 3 Gas
				Molten -> Desert: 2 Liquid, 4 Gas
				Frozen -> Arctic: 4 Liquid, 2 Gas
				Frozen -> Tundra: 3 Liquid, 3 Gas
